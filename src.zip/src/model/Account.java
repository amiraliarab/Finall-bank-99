package model;

public class Account {
    private String accountNumber ;
    private float credit;
    private AccountType accountType ;

    public Account(String accountNumber, float credit , AccountType accountType) {
        this.accountNumber = accountNumber;
        this.credit = credit;
        this.accountType = accountType ;
    }

    public String getAccountNumber() {
        return new StringBuilder().append(accountNumber).toString();
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public float getCredit() {
        return credit;
    }

    public void setCredit(float credit) {
        this.credit = credit;
    }

    public AccountType getAccountType() {
        return accountType;
    }

    public void setAccountType(AccountType accountType) {
        this.accountType = accountType;
    }

    @Override
    public String toString() {
        return "Account{" +
                "accountNumber='" + accountNumber + '\'' +
                ", credit=" + credit +
                ", accountType=" + accountType +
                '}';
    }
}
