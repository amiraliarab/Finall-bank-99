package model;

public enum AccountType {
    SavingAccount , CheckingAccount ,RetirementAccount , MoneyMarketAccount

}

