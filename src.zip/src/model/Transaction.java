package model;

import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class Transaction {

    private static List<Transaction> ALL_TRANSACTIONS = new ArrayList<>();

    private String message ;
    private String time ;

    public Transaction(String message) {
        this.message = message;
        this.time = new SimpleDateFormat("yyyy/MM/dd  HH:mm:ss").format(Calendar.getInstance().getTime());
    }
    public Transaction(String message ,String time) {
        this.message = message;
        this.time = time ;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    @Override
    public String toString() {
        return "Transaction{" +
                "message='" + message + '\'' +
                ", time='" + time + '\'' +
                '}';
    }

    public static List<Transaction> getAllTransactions() {
        return ALL_TRANSACTIONS;
    }

    public void saveToDB() throws SQLException {
        ALL_TRANSACTIONS.add(this);
        DataBase.addTransaction(this);
    }

}
