package model;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Card {


    private static List<Card> ALL_CARDS =new ArrayList<>();

    private String cardNumber ;
    private String cvv2 ;
    private String month;
    private String year ;
    private String password ;
    private String accountNumber ;


    public Card(String cardNumber, String cvv2, String month, String year , String password , String accountNumber) {
        this.cardNumber = cardNumber;
        this.cvv2 = cvv2;
        this.month = month;
        this.year = year;
        this.password = password ;
        this.accountNumber = accountNumber ;
    }

    public  void addToDB() throws SQLException {
        ALL_CARDS.add(this);
        DataBase.addCard(this);
    }

    public String getCardNumber() {
        return cardNumber;
    }

    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }

    public String getCvv2() {
        return cvv2;
    }

    public void setCvv2(String cvv2) {
        this.cvv2 = cvv2;
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public static List<Card> getAllCards() {
        return ALL_CARDS;
    }

    @Override
    public String toString() {
        return "Card{" +
                "cardNumber='" + cardNumber + '\'' +
                ", cvv2='" + cvv2 + '\'' +
                ", month='" + month + '\'' +
                ", year='" + year + '\'' +
                ", password='" + password + '\'' +
                '}';
    }
}

