package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import model.Banker;
import model.PageLoader;

import java.io.IOException;

public class BankerLoginController {

    @FXML
    private TextField username ;

    @FXML
    private PasswordField password;

    public void back(ActionEvent actionEvent) throws IOException {
        new PageLoader().load("../view/firstPage.fxml");
    }

    public void login(ActionEvent actionEvent) throws IOException {

        if(username.getText().isEmpty() || password.getText().isEmpty()){
            Alert alert = new Alert(Alert.AlertType.ERROR, "Please complete all the fields.");
            alert.showAndWait();
            return;
        }

        Banker found = null;

        for (Banker allBanker : Banker.getAllBankers()) {
            if(allBanker.getUsername().equals(username.getText())) found = allBanker ;
        }

        if(found == null){
            Alert alert = new Alert(Alert.AlertType.ERROR, "Username not found");
            alert.showAndWait();
            return;
        }

        if(found.getPassword().equals(password.getText())){
            new PageLoader().load("../view/bankerPanel.fxml");
            BankerPanelController.setBanker(found);
        }else{
            Alert alert = new Alert(Alert.AlertType.ERROR, "Password is not correct");
            alert.showAndWait();
            return;
        }

    }
}
