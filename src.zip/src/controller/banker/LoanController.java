package controller.banker;

import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;
import model.*;

import java.io.IOException;
import java.sql.SQLException;

public class LoanController {

    @FXML
    private TextField accountNumber ;

    @FXML
    private ChoiceBox<LoanType> loanType ;

    @FXML
    private TextField value ;


    public void initialize(){

        loanType.setItems(FXCollections.observableArrayList(
                LoanType.LongTerm , LoanType.ShortTerm
        ));

    }

    public void back(ActionEvent actionEvent) throws IOException {
        new PageLoader().load("../view/bankerPanel.fxml");

    }

    public void submit(ActionEvent actionEvent) throws IOException, SQLException {

        if(accountNumber.getText().isEmpty() || value.getText().isEmpty()){
            Alert alert = new Alert(Alert.AlertType.ERROR, "Please complete all the fields.");
            alert.showAndWait();
            return;
        }

        Loan loan = new Loan(accountNumber.getText() , loanType.getSelectionModel().getSelectedItem() , Float.valueOf(value.getText()));

        Customer customer = null ;

        for (Customer allCustomer : Customer.getAllCustomers()) {
            if(allCustomer.getAccount().getAccountNumber().equals(accountNumber.getText())) customer = allCustomer ;
        }

        if(customer == null){
            Alert alert = new Alert(Alert.AlertType.ERROR, "There is no Account with this account number.");
            alert.showAndWait();
            return;
        }

        if(customer.getAccount().getCredit() < Float.valueOf(value.getText())){
            Alert alert = new Alert(Alert.AlertType.ERROR, "You dont have enough credit for this loan");
            alert.showAndWait();
            return;
        }

        Alert alert = new Alert(Alert.AlertType.INFORMATION, "Loan submitted successfully.");
        alert.showAndWait();

        loan.saveToDB();



        back(new ActionEvent());
    }
}
