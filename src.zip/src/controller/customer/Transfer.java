package controller.customer;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import model.*;

import java.io.IOException;
import java.sql.SQLException;

public class Transfer {

    @FXML
    private TextField cardNumber ;

    @FXML
    private TextField cvv2 ;

    @FXML
    private TextField month ;

    @FXML
    private TextField year ;

    @FXML
    private TextField value ;

    @FXML
    private TextField receiver ;

    @FXML
    private PasswordField password ;



    public void back(ActionEvent actionEvent) throws IOException {
        new PageLoader().load("../view/firstPage.fxml");
    }

    public void transfer(ActionEvent actionEvent) throws IOException, SQLException {

        if(cardNumber.getText().isEmpty() ||
        cvv2.getText().isEmpty() ||
        month.getText().isEmpty() ||
        year.getText().isEmpty() ||
        value.getText().isEmpty() ||
        password.getText().isEmpty() ||
        receiver.getText().isEmpty()){

            Alert alert = new Alert(Alert.AlertType.ERROR, "Please complete all the fields.");
            alert.showAndWait();
            return;
        }

        Card sender = null ;

        for (Card check : Card.getAllCards()) {
            if(check.getCardNumber().equals(cardNumber.getText())) sender = check ;
        }

        if(sender == null){
            Alert alert = new Alert(Alert.AlertType.ERROR, "There is no credit card with " + cardNumber.getText() +" number");
            alert.showAndWait();
            return;
        }

        Card receiverCard = null ;

        for (Card check : Card.getAllCards()) {
            if(check.getCardNumber().equals(cardNumber.getText())) receiverCard = check ;
        }

        if(receiverCard == null){
            Alert alert = new Alert(Alert.AlertType.ERROR, "There is no credit card with "+ receiver.getText() +" number");
            alert.showAndWait();
            return;
        }

        Customer senderAccount = null  , receiverAccount = null;

        for (Customer check : Customer.getAllCustomers()) {
            if(check.getCard() == null) continue;
            if(check.getCard().getCardNumber().equals(cardNumber.getText())) senderAccount = check ;
            if(check.getCard().getCardNumber().equals(receiver.getText())) receiverAccount = check ;

        }

        if(senderAccount == null || receiverAccount == null){
            Alert alert = new Alert(Alert.AlertType.ERROR, "Error");
            alert.showAndWait();
            return;
        }

        if(senderAccount.getAccount().getCredit() < Float.valueOf(value.getText())){
            Alert alert = new Alert(Alert.AlertType.ERROR, "Not enough credit");
            alert.showAndWait();
            return;
        }

        if( ! cvv2.getText().equals(sender.getCvv2())){
            Alert alert = new Alert(Alert.AlertType.ERROR, "Wrong CVV2");
            alert.showAndWait();
            return;
        }

        if(! month.getText().equals(sender.getMonth())){
            Alert alert = new Alert(Alert.AlertType.ERROR, "Wrong Month");
            alert.showAndWait();
            return;
        }

        if(! year.getText().equals(sender.getYear())){
            Alert alert = new Alert(Alert.AlertType.ERROR, "Wrong Year");
            alert.showAndWait();
            return;
        }

        if(! password.getText().equals(sender.getPassword())){
            Alert alert = new Alert(Alert.AlertType.ERROR, "Wrong password");
            alert.showAndWait();
            return;
        }


        senderAccount.getAccount().setCredit(senderAccount.getAccount().getCredit() - Float.valueOf(value.getText()));
        receiverAccount.getAccount().setCredit(receiverAccount.getAccount().getCredit() + Float.valueOf(value.getText()));

        Alert alert = new Alert(Alert.AlertType.INFORMATION, "Transfer completed successfully.");
        alert.showAndWait();

        String message = "Transfer from card: " + cardNumber.getText() + " to card: " + receiver.getText();
        Transaction transaction = new Transaction(message);
        transaction.saveToDB();
        DataBase.updateCustomer(senderAccount.getAccount().getAccountNumber() , senderAccount.getAccount().getCredit());
        DataBase.updateCustomerList();


        back(new ActionEvent());
    }
}
