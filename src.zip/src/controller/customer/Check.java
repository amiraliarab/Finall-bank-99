package controller.customer;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import model.Card;
import model.Customer;
import model.PageLoader;
import model.Transaction;

import java.io.IOException;
import java.sql.SQLException;

public class Check {

    @FXML
    private TextField cardNumber ;

    @FXML
    private TextField cvv2 ;

    @FXML
    private TextField month ;

    @FXML
    private TextField year ;

    @FXML
    private PasswordField password ;

    public void back(ActionEvent actionEvent) throws IOException {
        new PageLoader().load("../view/firstPage.fxml");
    }

    public void check(ActionEvent actionEvent) throws IOException, SQLException {

        if(cardNumber.getText().isEmpty() ||
                cvv2.getText().isEmpty() ||
                month.getText().isEmpty() ||
                year.getText().isEmpty() ||
                password.getText().isEmpty()){

            Alert alert = new Alert(Alert.AlertType.ERROR, "Please complete all the fields.");
            alert.showAndWait();
            return;
        }

        Card sender = null ;

        for (Card check : Card.getAllCards()) {
            if(check.getCardNumber().equals(cardNumber.getText())) sender = check ;
        }

        if(sender == null){
            Alert alert = new Alert(Alert.AlertType.ERROR, "There is no credit card with " + cardNumber.getText() +" number");
            alert.showAndWait();
            return;
        }


        Customer found = null ;

        for (Customer check : Customer.getAllCustomers()) {
            if(check.getCard() == null) continue;
            if(check.getCard().getCardNumber().equals(cardNumber.getText())) found = check ;

        }

        if(found == null){
            Alert alert = new Alert(Alert.AlertType.ERROR, "Error");
            alert.showAndWait();
            return;
        }

        if( ! cvv2.getText().equals(sender.getCvv2())){
            Alert alert = new Alert(Alert.AlertType.ERROR, "Wrong CVV2");
            alert.showAndWait();
            return;
        }

        if(! month.getText().equals(sender.getMonth())){
            Alert alert = new Alert(Alert.AlertType.ERROR, "Wrong Month");
            alert.showAndWait();
            return;
        }

        if(! year.getText().equals(sender.getYear())){
            Alert alert = new Alert(Alert.AlertType.ERROR, "Wrong Year");
            alert.showAndWait();
            return;
        }

        if(! password.getText().equals(sender.getPassword())){
            Alert alert = new Alert(Alert.AlertType.ERROR, "Wrong password");
            alert.showAndWait();
            return;
        }

        Alert alert = new Alert(Alert.AlertType.INFORMATION, "Your card credit is: " + found.getAccount().getCredit());
        alert.showAndWait();

        String message = "Checking account from " + cardNumber.getText();
        Transaction transaction = new Transaction(message);
        transaction.saveToDB();

        back(new ActionEvent());
    }
}
