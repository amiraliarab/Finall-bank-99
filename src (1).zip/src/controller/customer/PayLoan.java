package controller.customer;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import model.*;

import java.io.IOException;
import java.sql.SQLException;

public class PayLoan {


    @FXML
    private TextField accountNumber ;

    @FXML
    private TextField value ;

    public void back(ActionEvent actionEvent) throws IOException {
        new PageLoader().load("../view/firstPage.fxml");
    }

    public void pay(ActionEvent actionEvent) throws IOException, SQLException {

        if(accountNumber.getText().isEmpty() || value.getText().isEmpty()){
            Alert alert = new Alert(Alert.AlertType.ERROR, "Please complete all the fields.");
            alert.showAndWait();
            return;
        }

        Customer customer = null;

        for (Customer allCustomer : Customer.getAllCustomers()) {
            if(allCustomer.getAccount().getAccountNumber().equals(accountNumber.getText())) customer = allCustomer ;
        }

        if(customer == null){
            Alert alert = new Alert(Alert.AlertType.ERROR, "There is no account with this account number");
            alert.showAndWait();
            return;
        }

        Loan loan = null ;

        for (Loan allLoan : Loan.getAllLoans()) {
            if(allLoan.getAccountNumber().equals(accountNumber.getText())) loan = allLoan ;
        }

        if(loan == null){
            Alert alert = new Alert(Alert.AlertType.ERROR, "There is no Loan fir this account number");
            alert.showAndWait();
            return;
        }

        if(Float.valueOf(value.getText()) > customer.getAccount().getCredit()){
            Alert alert = new Alert(Alert.AlertType.ERROR, "You do not have enough credit");
            alert.showAndWait();
            return;
        }

        customer.getAccount().setCredit(customer.getAccount().getCredit() - Float.valueOf(value.getText()));


        Alert alert = new Alert(Alert.AlertType.INFORMATION, "Loan payed successfully.");
        alert.showAndWait();

        String message = "Paying Loan from Account: " + accountNumber.getText()  + " Value: " +  value.getText();
        Transaction transaction = new Transaction(message);
        transaction.saveToDB();

        DataBase.updateCustomer(accountNumber.getText() , customer.getAccount().getCredit());
        DataBase.updateLoan(accountNumber.getText() , loan.getValue() - Float.valueOf(value.getText()));
        DataBase.updateCustomerList();
        DataBase.updateLoanList();
        back(new ActionEvent());


    }
}
