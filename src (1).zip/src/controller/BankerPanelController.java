package controller;

import controller.banker.CreateAccountController;
import javafx.event.ActionEvent;
import model.Banker;
import model.PageLoader;

import java.io.IOException;

public class BankerPanelController {

    private static Banker banker ;

    public void createAccount(ActionEvent actionEvent) throws IOException {
        CreateAccountController.setBanker(banker);
        new PageLoader().load("../view/banker/createAccount.fxml");
    }

    public void card(ActionEvent actionEvent) throws IOException {
        new PageLoader().load("../view/banker/cardIssuance.fxml");

    }

    public void loan(ActionEvent actionEvent) throws IOException {
        new PageLoader().load("../view/banker/loan.fxml");
    }

    public void czech(ActionEvent actionEvent) throws IOException {
        new PageLoader().load("../view/banker/czech.fxml");
    }

    public void logout(ActionEvent actionEvent) throws IOException {
        new PageLoader().load("../view/firstPage.fxml");
    }

    public static void setBanker(Banker banker) {
        BankerPanelController.banker = banker;
    }
}
