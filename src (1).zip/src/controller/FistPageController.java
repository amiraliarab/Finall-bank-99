package controller;

import javafx.event.ActionEvent;
import javafx.scene.input.MouseEvent;
import model.PageLoader;

import java.io.IOException;

public class FistPageController {
    public void transfer(ActionEvent actionEvent) throws IOException {
        new PageLoader().load("../view/customer/transfer.fxml");
    }

    public void checkAccount(ActionEvent actionEvent) throws IOException {
        new PageLoader().load("../view/customer/check.fxml");
    }

    public void payInstallment(ActionEvent actionEvent) throws IOException {
        new PageLoader().load("../view/customer/payLoan.fxml");
    }

    public void login(MouseEvent mouseEvent) throws IOException {
        new PageLoader().load("../view/bankerLogin.fxml");
    }
}
