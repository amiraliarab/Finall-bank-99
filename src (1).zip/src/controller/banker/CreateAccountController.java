package controller.banker;

import controller.BankerPanelController;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import model.*;

import java.io.IOException;
import java.sql.SQLException;

public class CreateAccountController {

    private static Banker banker ;


    @FXML
    private TextField firstName ;

    @FXML
    private TextField lastName ;

    @FXML
    private TextField age ;

    @FXML
    private TextField phoneNumber ;

    @FXML
    private TextField credit ;


    @FXML
    private TextArea address ;

    @FXML
    private ChoiceBox<AccountType> accountType ;


    public void initialize(){

        accountType.setItems(FXCollections.observableArrayList(
                AccountType.CheckingAccount,
                AccountType.MoneyMarketAccount,
                AccountType.RetirementAccount,
                AccountType.SavingAccount
        ));

    }

    public void back(ActionEvent actionEvent) throws IOException {
        BankerPanelController.setBanker(banker);
        new PageLoader().load("../view/bankerPanel.fxml");
    }

    public void submit(ActionEvent actionEvent) throws IOException, SQLException {

        if(firstName.getText().isEmpty() ||
        lastName.getText().isEmpty()||
        age.getText().isEmpty() ||
        phoneNumber.getText().isEmpty() ||
        address.getText().isEmpty()||
        credit.getText().isEmpty()){
            Alert alert = new Alert(Alert.AlertType.ERROR, "Please complete all the fields.");
            alert.showAndWait();
            return;
        }

        if(!age.getText().chars().allMatch( Character::isDigit )){
            Alert alert = new Alert(Alert.AlertType.ERROR, "Age should be integer.");
            alert.showAndWait();
            return;
        }

        Customer customer = new Customer(firstName.getText() , lastName.getText() , Integer.valueOf(age.getText())  ,
                address.getText() , phoneNumber.getText()  , Float.valueOf(credit.getText()) , accountType.getSelectionModel().getSelectedItem());

        if(accountType.getSelectionModel().toString() == AccountType.SavingAccount.toString()){
            customer.getAccount().setAccountType(AccountType.SavingAccount);
        }
        else if(accountType.getSelectionModel().toString() == AccountType.RetirementAccount.toString()){
            customer.getAccount().setAccountType(AccountType.RetirementAccount);
        }
        else if(accountType.getSelectionModel().toString() == AccountType.MoneyMarketAccount.toString()){
            customer.getAccount().setAccountType(AccountType.MoneyMarketAccount);
        }
        else if(accountType.getSelectionModel().toString() == AccountType.CheckingAccount.toString()){
            customer.getAccount().setAccountType(AccountType.CheckingAccount);
        }
        else{
            customer.getAccount().setAccountType(AccountType.SavingAccount);
        }

        customer.saveToDB();
;
        Alert alert = new Alert(Alert.AlertType.INFORMATION, "Account created successfully.");
        alert.showAndWait();
        back(new ActionEvent());
    }

    public static void setBanker(Banker banker) {
        CreateAccountController.banker = banker;
    }
}
