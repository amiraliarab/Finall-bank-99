package controller.banker;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import model.*;

import java.io.IOException;
import java.sql.SQLException;

public class CardIssuanceController {

    @FXML
    private TextField accountNumber ;

    @FXML
    private TextField cardNumber ;
    @FXML

    private TextField cvv2 ;
    @FXML

    private TextField month ;

    @FXML
    private TextField year ;

    @FXML
    private PasswordField password ;


    private static Banker banker ;

    public void back(ActionEvent actionEvent) throws IOException {
        new PageLoader().load("../view/bankerPanel.fxml");
    }

    public void submit(ActionEvent actionEvent) throws IOException, SQLException {

        if(accountNumber.getText().isEmpty() ||
        cardNumber.getText().isEmpty() ||
        cvv2.getText().isEmpty() ||
        month.getText().isEmpty()||
        year.getText().isEmpty()||
        password.getText().isEmpty()){
            Alert alert = new Alert(Alert.AlertType.ERROR, "Please complete all the fields.");
            alert.showAndWait();
            return;
        }

        Customer customer = null ;

        for (Customer check : Customer.getAllCustomers()) {
            if(check.getAccount().getAccountNumber().equals(accountNumber.getText())) customer = check ;
        }

        if(customer == null){
            Alert alert = new Alert(Alert.AlertType.ERROR, "No account with " + accountNumber.getText() + " account number");
            alert.showAndWait();
            return;
        }

        if(customer.isHasCard()){
            Alert alert = new Alert(Alert.AlertType.ERROR, "This account number already has Credit card");
            alert.showAndWait();
            return;
        }

        Card card = new Card(cardNumber.getText() , cvv2.getText() , month.getText() , year.getText() , password.getText() , accountNumber.getText());
        customer.setCard(card);
        customer.setHasCard(true);

        DataBase.updateCustomer(customer);
        card.addToDB();

        Alert alert = new Alert(Alert.AlertType.INFORMATION, "Credit card registered.");
        alert.showAndWait();

        back(new ActionEvent());
    }

    public static void setBanker(Banker banker) {
        CardIssuanceController.banker = banker;
    }
}
