package controller.banker;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import model.Customer;
import model.Czech;
import model.PageLoader;

import java.io.IOException;
import java.sql.SQLException;

public class CzechController {

    @FXML
    private TextField from;

    @FXML
    private TextField to;

    @FXML
    private TextField value;

    @FXML
    private TextField day;

    @FXML
    private TextField month;

    @FXML
    private TextField year;


    public void back(ActionEvent actionEvent) throws IOException {
        new PageLoader().load("../view/bankerPanel.fxml");
    }

    public void submit(ActionEvent actionEvent) throws IOException, SQLException {


        if(from.getText().isEmpty() || month.getText().isEmpty() || to.getText().isEmpty() || day.getText().isEmpty() ||
        year.getText().isEmpty()){
            Alert alert = new Alert(Alert.AlertType.ERROR, "Please complete all the fields.");
            alert.showAndWait();
            return;
        }

        Customer fromC = null  , toC = null ;

        for (Customer allCustomer : Customer.getAllCustomers()) {
            if(allCustomer.getAccount().getAccountNumber().equals(from.getText())) fromC = allCustomer;
            if(allCustomer.getAccount().getAccountNumber().equals(to.getText())) toC = allCustomer;

        }

        if(fromC == null){
            Alert alert = new Alert(Alert.AlertType.ERROR, "Owner account number is not valid.");
            alert.showAndWait();
            return;
        }

        if(toC== null){
            Alert alert = new Alert(Alert.AlertType.ERROR, "Receiver account number is not valid.");
            alert.showAndWait();
            return;
        }

        if(fromC.getAccount().getCredit() < Float.valueOf(value.getText())){
            Alert alert = new Alert(Alert.AlertType.ERROR, "Owner have not enough credit.");
            alert.showAndWait();
            return;
        }

        Czech czech = new Czech(from.getText() , to.getText()  ,Float.valueOf(value.getText()) , year.getText() , month.getText() , day.getText() );
        czech.saveToDB();

        Alert alert = new Alert(Alert.AlertType.INFORMATION, "Czech submitted successfully.");
        alert.showAndWait();

        back(new ActionEvent());

    }
}
