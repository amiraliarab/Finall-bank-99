package model;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Calendar;
import java.util.Date;

public class DataBase {

    private static final String URL = "jdbc:mysql://localhost:3306/MySQL";
    private static final String user = "root";
    private static final String password = "root";
    private static  Connection connection;

    static {
        try {
            connection = DriverManager.getConnection(URL , user, password);
        } catch (SQLException e) {
                System.out.println("Can not connect to DataBase");
        }
    }


    /**
     * Banker
     */
    public static void addBanker(Banker banker) throws SQLException {

        connection = DriverManager.getConnection(URL , user , password);

        String sql = "INSERT INTO db.bankers (username, password , time)" +
                "VALUES (?, ?,?)";

        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setString(1,banker.getUsername() );
        preparedStatement.setString(2 , banker.getPassword());
        preparedStatement.setString(3 , new SimpleDateFormat("yyyy/MM/dd  HH:mm:ss").format(Calendar.getInstance().getTime()));
        preparedStatement.executeUpdate();

        connection.close();
        System.out.println("Banker added to DB");
    }
    public static void updateBankersList() throws SQLException {

        connection = DriverManager.getConnection(URL , user , password);

        String sql = "SELECT * FROM db.bankers";
        Statement statement = connection.createStatement();

        ResultSet resultSet = statement.executeQuery(sql);

        while (resultSet.next())
        {
            String username = resultSet.getString("username");
            String password = resultSet.getString("password");
            Banker banker = new Banker(username , password);
            Banker.getAllBankers().add(banker);

        }
        connection.close();
        System.out.println("Banker list updated" + " Size:"  +Banker.getAllBankers().size());
    }

    /**
     * Customer
     */
    public static void addCustomer(Customer customer) throws SQLException {

        connection = DriverManager.getConnection(URL , user , password);

        String sql = "INSERT INTO db.customers (firstName, lastName , age , address , phoneNumber  , credit , accountType , hasCard ,accountNumber , cardNumber ,time)" +
                "VALUES (?, ? , ? , ? , ? ,? ,? , ? , ? , ?,?)";

        PreparedStatement preparedStatement = connection.prepareStatement(sql);

        preparedStatement.setString(1,customer.getFistName());
        preparedStatement.setString(2,customer.getLastName());
        preparedStatement.setInt(3 , customer.getAge());
        preparedStatement.setString(4,customer.getAddress());
        preparedStatement.setString(5, customer.getPhoneNumber());
        preparedStatement.setFloat(6 , customer.getAccount().getCredit());
        preparedStatement.setString(7 , customer.getAccount().getAccountType().toString());
        preparedStatement.setBoolean(8 , customer.isHasCard());
        preparedStatement.setString(9 , customer.getAccount().getAccountNumber());
        preparedStatement.setString(10 , null);
        preparedStatement.setString(11 , new SimpleDateFormat("yyyy/MM/dd  HH:mm:ss").format(Calendar.getInstance().getTime()));


        preparedStatement.executeUpdate();

        connection.close();
        System.out.println("Customer added to DB");
    }
    public static void updateCustomerList() throws SQLException {

        connection = DriverManager.getConnection(URL , user , password);

        String sql = "SELECT * FROM db.customers";

        Statement statement = connection.createStatement();

        ResultSet resultSet = statement.executeQuery(sql);

        while (resultSet.next())
        {
            String fistName = resultSet.getString("firstName");
            String lastName = resultSet.getString("lastName");
            int age = resultSet.getInt("age");
            String address = resultSet.getString("address");
            String phoneNumber = resultSet.getString("phoneNumber");
            float credit = resultSet.getFloat("credit");
            String accountType = resultSet.getString("accountType");
            boolean hasCard = resultSet.getBoolean("hasCard");
            String accountNumber = resultSet.getString("accountNumber");
            String cardNumber = resultSet.getString("cardNumber");
            Card card  = null ;


            Account account = new Account(accountNumber , credit , Customer.getAccountType(accountType));
            Customer customer = new Customer(fistName , lastName , age , address , phoneNumber ,  credit , account , hasCard ,  card);

           Customer.getAllCustomers().add(customer);

        }
        connection.close();
        System.out.println("Customer list updated" + " Size:"  +Customer.getAllCustomers().size());
    }
    public static void updateCustomer(Customer customer) throws SQLException {

        connection = DriverManager.getConnection(URL , user , password);

        String query = "update db.customers set hasCard = ? , cardNumber = ?  where accountNumber = ?";

        PreparedStatement preparedStmt = connection.prepareStatement(query);

        preparedStmt.setBoolean(1, customer.isHasCard());
        preparedStmt.setString(2, customer.getCard().getCardNumber());
        preparedStmt.setString(3, customer.getAccount().getAccountNumber());
        preparedStmt.executeUpdate();

        connection.close();
        System.out.println("Customer updated");


    }
    public static void updateCustomer(String accountNumber , float credit) throws SQLException {

        connection = DriverManager.getConnection(URL , user , password);

        String query = "update db.customers set  credit = ?  where accountNumber = ?";

        PreparedStatement preparedStmt = connection.prepareStatement(query);

        preparedStmt.setFloat(1, credit);
        preparedStmt.setString(2, accountNumber);

        preparedStmt.executeUpdate();

        connection.close();
        System.out.println("Customer updated");


    }

    /**
     * Card
     */
    public static Card getCard(String accountNumber) throws SQLException {

        connection = DriverManager.getConnection(URL , user , password);

        Card card  =null;
        String query = "SELECT * FROM db.cards WHERE accountNumber='" + accountNumber + "'";

        Statement statement = connection.createStatement();

        ResultSet resultSet = statement.executeQuery(query);

        while (resultSet.next())
        {

            String cvv2 = resultSet.getString("cvv2");
            String month = resultSet.getString("month");
            String year = resultSet.getString("year");
            String password = resultSet.getString("password");
            String cardNumber = resultSet.getString("cardNumber");
             card = new Card(cardNumber , cvv2 , month , year , password ,accountNumber );
        }
        connection.close();
        return card  ;
    }
    public static void addCard(Card card) throws SQLException {
        connection = DriverManager.getConnection(URL , user , password);

        String sql = "INSERT INTO db.cards (cardNumber, cvv2 , month , year , password , accountNumber , time)" +
                "VALUES (?, ? , ? , ? , ? , ?,?)";

        PreparedStatement preparedStatement = connection.prepareStatement(sql);

        preparedStatement.setString(1,card.getCardNumber() );
        preparedStatement.setString(2,card.getCvv2() );
        preparedStatement.setString(3,card.getMonth() );
        preparedStatement.setString(4,card.getYear() );
        preparedStatement.setString(5,card.getPassword() );
        preparedStatement.setString(6,card.getAccountNumber() );
        preparedStatement.setString(7,new SimpleDateFormat("yyyy/MM/dd  HH:mm:ss").format(Calendar.getInstance().getTime()) );

        preparedStatement.executeUpdate();

        connection.close();
        System.out.println("Card added to DB");
    }
    public static void updateCardList() throws SQLException {

        connection = DriverManager.getConnection(URL , user , password);

        String sql = "SELECT * FROM db.cards";
        Statement statement = connection.createStatement();

        ResultSet resultSet = statement.executeQuery(sql);

        while (resultSet.next())
        {
            String cardNumber = resultSet.getString("cardNumber");
            String cvv2 = resultSet.getString("cvv2");
            String month = resultSet.getString("month");
            String year = resultSet.getString("year");
            String password = resultSet.getString("password");
            String accountNumber = resultSet.getString("password");
            Card card = new Card(cardNumber , cvv2 , month , year , password , accountNumber);
            Card.getAllCards().add(card);

            for (Customer customer : Customer.getAllCustomers()) {
                if(customer.getAccount().getAccountNumber().equals(accountNumber)) customer.setCard(card);
            }

        }
        connection.close();
        System.out.println("Card list updated" + " Size:"  +Card.getAllCards().size());
    }

    /**
     * Loan
     */
    public static void addLoan(Loan loan) throws SQLException {

        connection = DriverManager.getConnection(URL , user , password);

        String sql = "INSERT INTO db.loan (accountNumber, loanType , value ,time)" +
                "VALUES (?, ? , ?,?)";

        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setString(1,loan.getAccountNumber() );
        preparedStatement.setString(2 , loan.getLoanType().toString());
        preparedStatement.setFloat(3 , loan.getValue());
        preparedStatement.setString(4 , new SimpleDateFormat("yyyy/MM/dd  HH:mm:ss").format(Calendar.getInstance().getTime()));
        preparedStatement.executeUpdate();

        connection.close();
        System.out.println("Loan added to DB");
    }
    public static void updateLoanList() throws SQLException {

        connection = DriverManager.getConnection(URL , user , password);

        String sql = "SELECT * FROM db.loan";

        Statement statement = connection.createStatement();

        ResultSet resultSet = statement.executeQuery(sql);

        while (resultSet.next())
        {
            String accountNumber = resultSet.getString("accountNumber");
            String loanType = resultSet.getString("loanType");
            float value = resultSet.getFloat("value");

            Loan loan = new Loan(accountNumber , Loan.getLoanType(loanType) , value);

            Loan.getAllLoans().add(loan);
        }
        connection.close();
        System.out.println("Loan list updated" + " Size:"  +Loan.getAllLoans().size());
    }
    public static void updateLoan(String accountNumber , float value) throws SQLException {

        connection = DriverManager.getConnection(URL , user , password);

        String query = "update db.loan set  value = ?  where accountNumber = ?";

        PreparedStatement preparedStmt = connection.prepareStatement(query);

        preparedStmt.setFloat(1,  value);
        preparedStmt.setString(2, accountNumber);

        preparedStmt.executeUpdate();

        connection.close();
        System.out.println("Customer updated");


    }

    /**
     * Czech
     */
    public static void addCzech(Czech czech) throws SQLException {

        connection = DriverManager.getConnection(URL , user , password);

        String sql = "INSERT INTO db.czech (sender , receiver , value , year , month  , day , time)" +
                "VALUES (?,?,?,?,?,?,?)";

        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setString(1,czech.getSender() );
        preparedStatement.setString(2,czech.getReceiver() );
        preparedStatement.setFloat(3,czech.getValue() );
        preparedStatement.setString(4,czech.getYear());
        preparedStatement.setString(5,czech.getMonth());
        preparedStatement.setString(6,czech.getDay());
        preparedStatement.setString(7,new SimpleDateFormat("yyyy/MM/dd  HH:mm:ss").format(Calendar.getInstance().getTime()));

        preparedStatement.executeUpdate();

        connection.close();
        System.out.println("Czech added to DB");
    }
    public static void  updateCzechList() throws SQLException {

        connection = DriverManager.getConnection(URL , user , password);

        String sql = "SELECT * FROM db.czech";

        Statement statement = connection.createStatement();

        ResultSet resultSet = statement.executeQuery(sql);

        while (resultSet.next())
        {
            String from = resultSet.getString("sender");
            String to = resultSet.getString("receiver");
            float value = resultSet.getFloat("value");
            String day = resultSet.getString("year");
            String month = resultSet.getString("month");
            String year = resultSet.getString("day");


           Czech czech = new Czech(from , to , value ,day , month , year);

            Czech.getAllCzechs().add(czech);
        }
        connection.close();
        System.out.println("Czech list updated" + " Size:"  +Czech.getAllCzechs().size());
    }


    /**
     * Transaction
     */
    public static void addTransaction(Transaction transaction) throws SQLException {

        connection = DriverManager.getConnection(URL , user , password);

        String sql = "INSERT INTO db.transaction (message , time)" +
                "VALUES (?,?)";

        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setString(1,transaction.getMessage() );
        preparedStatement.setString(2 , transaction.getTime());

        preparedStatement.executeUpdate();

        connection.close();
        System.out.println("Transaction added to DB");
    }
    public static void  updateTransactionList() throws SQLException {

        connection = DriverManager.getConnection(URL , user , password);

        String sql = "SELECT * FROM db.transaction";

        Statement statement = connection.createStatement();

        ResultSet resultSet = statement.executeQuery(sql);

        while (resultSet.next())
        {
            String message = resultSet.getString("message");
            String time = resultSet.getString("time");

            Transaction transaction = new Transaction(message , time);
            Transaction.getAllTransactions().add(transaction);
        }
        connection.close();
        System.out.println("Transaction list updated" + " Size:"  +Transaction.getAllTransactions().size());
    }


    public static String getPassword() {
        return password;
    }

    public static Connection getConnection() {
        return connection;
    }

    public static String getUser() {
        return user;
    }

    public static String getURL() {
        return URL;
    }
}
