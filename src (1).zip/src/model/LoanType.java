package model;

public enum LoanType {
    ShortTerm , LongTerm
}
