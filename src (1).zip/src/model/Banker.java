package model;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Banker {

    private String username;
    private String password ;

    private static List<Banker> ALL_BANKERS = new ArrayList<>();

    public Banker(String username , String password) throws SQLException {
        super();
        this.username = username ;
        this.password  =password ;
    }

    public String getUsername(){
        return this.username ;
    }

    public String getPassword(){
        return this.username ;
    }

    public static List<Banker> getAllBankers() {
        return ALL_BANKERS;
    }



}
