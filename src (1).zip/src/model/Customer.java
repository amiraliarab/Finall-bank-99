package model;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Customer {

    private static int counter =0 ;

    private static List<Customer> ALL_CUSTOMERS = new ArrayList<>();
    private static String GENERATE_ACCOUNT_NUMBER   = "1000000000" ;


    private String fistName;
    private String lastName;
    private int age ;
    private String address ;
    private String phoneNumber;
    private Card card ;
    private Account account ;
    private boolean hasCard = false ;



    public Customer(String fistName , String lastName , int age , String address , String phoneNumber  , float credit , AccountType accountType){
        this.fistName = fistName ;
        this.lastName = lastName ;
        this.age = age ;
        this.address = address ;
        this.phoneNumber = phoneNumber ;
        Account account = new Account(getNumber() , credit , accountType);
        this.account = account ;
        this.card = null ;
    }


    public Customer(String fistName , String lastName , int age , String address , String phoneNumber  , float credit,  Account account , boolean hasCard , Card card){
        this.fistName = fistName ;
        this.lastName = lastName ;
        this.age = age ;
        this.address = address ;
        this.phoneNumber = phoneNumber ;
        this.account = account ;
        this.card = null ;
        this.account = account ;
        this.hasCard = hasCard ;
        this.card = card ;

    }

    public void saveToDB() throws SQLException {
        ALL_CUSTOMERS.add(this);
        DataBase.addCustomer(this);
    }


    public static List<Customer> getAllCustomers() {
        return ALL_CUSTOMERS;
    }

    public Account getAccount() {
        return account;
    }

    @Override
    public String toString() {
        return "Customer{" +
                "fistName='" + fistName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", age=" + age +
                ", address='" + address + '\'' +
                ", phoneNumber='" + phoneNumber + '\'' +
                ", card=" + card +
                ", account=" + account +
                ", hasCard=" + hasCard +
                '}';
    }

    public static void setAllCustomers(List<Customer> allCustomers) {
        ALL_CUSTOMERS = allCustomers;
    }


    public static String getGenerateAccountNumber() {
        return GENERATE_ACCOUNT_NUMBER;
    }

    public static void setGenerateAccountNumber(String generateAccountNumber) {
        GENERATE_ACCOUNT_NUMBER = generateAccountNumber;
    }


    public String getFistName() {
        return fistName;
    }

    public void setFistName(String fistName) {
        this.fistName = fistName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public Card getCard() {
        return card;
    }

    public void setCard(Card card) {
        this.card = card;
    }

    public void setAccount(Account account) {
        this.account = account;
    }

    public boolean isHasCard() {
        return hasCard;
    }

    public void setHasCard(boolean hasCard) {
        this.hasCard = hasCard;
    }


    public static AccountType getAccountType(String s){

        if(s =="SavingAccount" ) return AccountType.SavingAccount;
        else if(s == "CheckingAccount") return AccountType.CheckingAccount;
        else if (s == "RetirementAccount") return AccountType.RetirementAccount;
        else return AccountType.MoneyMarketAccount;
    }

    public String getNumber(){
        int length = String.valueOf(counter).length();
        return GENERATE_ACCOUNT_NUMBER.substring(0 , 10 - length) + String.valueOf(counter ++);

    }

    public static void main(String[] args) {




    }
}
