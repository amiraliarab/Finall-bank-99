package model;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Loan {


    private static List<Loan> ALL_LOANS  = new ArrayList<>();

    private String accountNumber ;
    private LoanType loanType ;
    private float value ;


    public Loan(String accountNumber, LoanType loanType, float value) {
        this.accountNumber = accountNumber;
        this.loanType = loanType;
        this.value = value;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public LoanType getLoanType() {
        return loanType;
    }

    public void setLoanType(LoanType loanType) {
        this.loanType = loanType;
    }

    public float getValue() {
        return value;
    }

    public void setValue(float value) {
        this.value = value;
    }

    public static List<Loan> getAllLoans() {
        return ALL_LOANS;
    }

    public static void setAllLoans(List<Loan> allLoans) {
        ALL_LOANS = allLoans;
    }

    public void saveToDB() throws SQLException {
        ALL_LOANS.add(this);
        DataBase.addLoan(this);
    }

    public static LoanType getLoanType(String s){
        if(s.equals("ShortTerm")){
            return LoanType.ShortTerm;
        }
        else {
            return LoanType.LongTerm;
        }
    }
}
