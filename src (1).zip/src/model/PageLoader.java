package model;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

import java.io.IOException;
import java.net.URL;


public class PageLoader {

    final static int HEIGHT = 600;
    final static int WIDTH = 400;
    private static Stage stage;


    public static void initStage(Stage primaryStage) {

        stage = primaryStage;
        stage.setTitle("Bank");
        stage.setResizable(false);
        stage.setWidth(WIDTH);
        stage.setHeight(HEIGHT);
        stage.setResizable(true);
        stage.setResizable(false);
//        stage.setMinWidth(500);
//        stage.setMinHeight(700);
        primaryStage.initStyle(StageStyle.DECORATED);

    }

    public void load(String url) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource(url));
        stage.setScene(new Scene(root, WIDTH, HEIGHT));
        stage.show();
    }

    public void load(String url, Object Controller) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource(url));
        fxmlLoader.setController(Controller);
        fxmlLoader.load();


    }


}
