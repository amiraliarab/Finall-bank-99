package model;
import javafx.application.Application;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Main extends Application {


    @Override
    public void init() throws IOException, ClassNotFoundException {


    }

    @Override
    public void start(Stage primaryStage) throws Exception {


        PageLoader.initStage(primaryStage);
        new PageLoader().load("../view/firstPage.fxml");



    }


    public static void main(String[] args) throws SQLException {
        try{
            initialize();
        }catch (Exception e){
            System.out.println("DataBase is not running");
            return;
        }

        launch(args);
    }

    public static void initialize() throws SQLException {

        Connection connection = DataBase.getConnection();


        connection = DriverManager.getConnection(DataBase.getURL() , DataBase.getUser() , DataBase.getPassword());


        DataBase.updateBankersList();

        if(Banker.getAllBankers().isEmpty())
            DataBase.addBanker(new Banker("admin" , "admin"));

        DataBase.updateBankersList();

        DataBase.updateCustomerList();
        DataBase.updateCardList();
        DataBase.updateLoanList();
        DataBase.updateCzechList();
        DataBase.updateTransactionList();
        for (Customer allCustomer : Customer.getAllCustomers()) {
            if(allCustomer.isHasCard()){
                allCustomer.setCard(DataBase.getCard(allCustomer.getAccount().getAccountNumber()));
            }
        }
        System.out.println("Card setting done");

    }

}
