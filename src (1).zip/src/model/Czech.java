package model;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Czech {

    private static List<Czech> ALL_CZECHS = new ArrayList<>();

    private String sender;
    private String receiver;
    private float value ;
    private String year , month , day;

    public Czech(String sender, String to, float value, String year, String month, String day) {
        this.sender = sender;
        this.receiver = to;
        this.value = value;
        this.year = year;
        this.month = month;
        this.day = day;
    }

    public static List<Czech> getAllCzechs() {
        return ALL_CZECHS;
    }

    public static void setAllCzechs(List<Czech> allCzechs) {
        ALL_CZECHS = allCzechs;
    }

    public String getSender() {
        return sender;
    }

    public void setSender(String sender) {
        this.sender = sender;
    }

    public String getReceiver() {
        return receiver;
    }

    public void setReceiver(String receiver) {
        this.receiver = receiver;
    }

    public float getValue() {
        return value;
    }

    public void setValue(float value) {
        this.value = value;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public String getDay() {
        return day;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public void saveToDB() throws SQLException {
        ALL_CZECHS.add(this);
        DataBase.addCzech(this);
    }
}
